import React from "react";

export default function HomePage(){
    return(
        <div className="main-page home-page">
            <h1>Home Page</h1>
        </div>
    )
}